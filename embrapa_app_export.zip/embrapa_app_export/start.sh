#!/bin/bash

# Script de inicialização para a aplicação Embrapa Vitivinicultura

echo "Iniciando a aplicação Embrapa Vitivinicultura..."

# Verificar se o arquivo CSV existe
if [ ! -f "analise_agregada_tipo_uva.csv" ]; then
    echo "Executando coleta de dados..."
    python fetch_data.py
else
    echo "Arquivo de dados encontrado. Pulando coleta."
fi

# Garantir que o arquivo CSV esteja disponível para o frontend
mkdir -p /app/client/public/data
cp analise_agregada_tipo_uva.csv /app/client/public/data/

# Iniciar o servidor frontend
echo "Iniciando servidor frontend na porta 3000..."
cd /app/client/dist && serve -s -l 3000 &

echo "Aplicação iniciada com sucesso!"
echo "Frontend disponível em: http://localhost:3000"

# Manter o container em execução
tail -f /dev/null
