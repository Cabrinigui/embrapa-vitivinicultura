import requests
import pandas as pd
from tqdm import tqdm
import os
import random
import string

BASE_URL = "https://api-embrapa-vitivinicultura-181232612764.southamerica-east1.run.app"
TIPOS_UVA = ["vinhos-de-mesa", "espumantes", "uvas-frescas", "uvas-passas", "suco-de-uva"]
ANOS = range(1970, 2024) # Dados de 1970 a 2023

# --- Autenticação ---
# Gerar credenciais aleatórias simples para teste
USERNAME = "user_" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
PASSWORD = "pass" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
EMAIL = USERNAME + "@example.com"

def register_user(username, password, email):
    """Registra um novo usuário na API."""
    url = f"{BASE_URL}/register"
    payload = {"username": username, "password": password, "email": email}
    try:
        response = requests.post(url, json=payload, timeout=30)
        if response.status_code == 201:
            print(f"Usuário {username} registrado com sucesso.")
            return True
        elif response.status_code == 400 and "already exists" in response.json().get("message", "").lower():
             print(f"Usuário {username} já existe.")
             return True # Considerar como sucesso se já existe para poder logar
        else:
            print(f"Falha ao registrar usuário {username}. Status: {response.status_code}, Resposta: {response.text}")
            response.raise_for_status()
            return False
    except requests.exceptions.RequestException as e:
        print(f"Erro na requisição de registro: {e}")
        return False

def login_user(username, password):
    """Realiza login e retorna o token JWT."""
    url = f"{BASE_URL}/login"
    payload = {"username": username, "password": password}
    try:
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
        token = response.json().get("access_token")
        if token:
            print("Login bem-sucedido. Token JWT obtido.")
            return token
        else:
            print("Falha no login: Token não encontrado na resposta.")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Erro na requisição de login: {e}")
        return None

# --- Coleta de Dados ---
def fetch_data_for_year_type(endpoint, ano, tipo, token):
    """Busca dados para um ano e tipo específicos em um endpoint, usando token JWT."""
    url = f"{BASE_URL}/{endpoint}?ano={ano}&tipo={tipo}"
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status() # Lança exceção para códigos de erro HTTP
        return response.json()
    except requests.exceptions.RequestException as e:
        # Não imprimir erro para 404 (Not Found), pois pode significar ausência de dados para o ano/tipo
        if response.status_code != 404:
             print(f"Erro ao buscar dados para {endpoint}, ano {ano}, tipo {tipo}: {e} (Status: {response.status_code})")
        return []

def aggregate_data(token):
    """Busca e agrega dados de importação e exportação por tipo de uva usando token JWT."""
    if not token:
        print("Token JWT inválido. Abortando coleta de dados.")
        return None

    all_data = {"importacoes": [], "exportacoes": []}

    for endpoint in ["importacoes", "exportacoes"]:
        print(f"\nBuscando dados de {endpoint}...")
        # Usar tqdm para barra de progresso combinando anos e tipos
        for ano in tqdm(ANOS, desc=f"Anos ({endpoint})"):
            for tipo in TIPOS_UVA:
                data = fetch_data_for_year_type(endpoint, ano, tipo, token)
                if data: # Adiciona apenas se a resposta não for vazia/erro
                    all_data[endpoint].extend(data)

    # Converter para DataFrames para facilitar a agregação
    df_import = pd.DataFrame(all_data["importacoes"])
    df_export = pd.DataFrame(all_data["exportacoes"])

    # Garantir que as colunas 'quantidade' e 'valor' sejam numéricas, tratando erros
    for df in [df_import, df_export]:
        if not df.empty:
            # Verificar se as colunas existem antes de tentar converter
            if 'quantidade' in df.columns:
                df["quantidade"] = pd.to_numeric(df["quantidade"], errors="coerce").fillna(0)
            else:
                df["quantidade"] = 0 # Criar coluna com zeros se não existir
            if 'valor' in df.columns:
                 df["valor"] = pd.to_numeric(df["valor"], errors="coerce").fillna(0)
            else:
                 df["valor"] = 0 # Criar coluna com zeros se não existir
        else:
             # Criar DataFrames vazios com as colunas esperadas se não houver dados
             if endpoint == 'importacoes':
                 df_import = pd.DataFrame(columns=['tipo', 'ano', 'pais', 'quantidade', 'valor'])
             else:
                 df_export = pd.DataFrame(columns=['tipo', 'ano', 'pais', 'quantidade', 'valor'])


    # Agregar os dados: somar quantidade e valor por tipo
    agg_import = df_import.groupby("tipo")[["quantidade", "valor"]].sum().reset_index() if not df_import.empty else pd.DataFrame(columns=["tipo", "quantidade", "valor"])
    agg_export = df_export.groupby("tipo")[["quantidade", "valor"]].sum().reset_index() if not df_export.empty else pd.DataFrame(columns=["tipo", "quantidade", "valor"])

    # Renomear colunas para clareza
    agg_import.rename(columns={"quantidade": "quantidade_importada", "valor": "valor_importado"}, inplace=True)
    agg_export.rename(columns={"quantidade": "quantidade_exportada", "valor": "valor_exportado"}, inplace=True)

    # Mesclar os resultados
    df_final = pd.merge(agg_import, agg_export, on="tipo", how="outer").fillna(0)

    print("\nAnálise Agregada (Total por Tipo de Uva):")
    print(df_final.to_string())

    # Salvar resultados em CSV
    output_path = "/home/ubuntu/embrapa_app/analise_agregada_tipo_uva.csv"
    df_final.to_csv(output_path, index=False)
    print(f"\nResultados salvos em {output_path}")

    return df_final

if __name__ == "__main__":
    print(f"Tentando registrar/logar com usuário: {USERNAME}")
    # Tenta registrar o usuário. Se já existir ou for criado com sucesso, tenta logar.
    if register_user(USERNAME, PASSWORD, EMAIL):
        jwt_token = login_user(USERNAME, PASSWORD)
        if jwt_token:
            aggregate_data(jwt_token)
        else:
            print("Não foi possível obter o token JWT após o registro/login.")
    else:
        print("Não foi possível registrar o usuário.")

